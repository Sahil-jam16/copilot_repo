import React from 'react';
const Admin = () => <div>Admin Panel</div>;
export default Admin;
